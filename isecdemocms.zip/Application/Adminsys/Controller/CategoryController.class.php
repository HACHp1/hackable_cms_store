<?php

namespace Adminsys\Controller;
class CategoryController extends AdminController {

    public function index(){
       //$this->checkadmin(array('2'));
       
       $this->display();
    }

}