<?php

namespace Adminsys\Controller;
use Think\Controller;
class SystemController extends Controller {

    public function class_sorting(){
        cz_class_sorting("cz_article_class","0",$_GET['Point'],$_GET['id'],$_GET['sid'],$_GET['numberid'],$config);
        echo "<script>self.location=document.referrer;</script>";
        exit();	
        }    

    public function setupdate(){
        //初始化系统配置文件
        require APP_PATH.'Adminsys/Conf/system.php';
        foreach($_POST as $key => $value){
            if(array_key_exists($key,$sysconfig)){
                 $sysconfig[$key]=$value;
            }
         }
         $str = '<?php $sysconfig=';
         $str .= var_export($sysconfig,true);
         $str .= ';';
         if(file_put_contents(APP_PATH.'Adminsys/Conf/system.php',$str)){
             echo 1;
         }else{
             echo 0;
         }
     }

     public function index_class_edit_save(){
        $id=I('post.id',0,'intval');
        $PartID=I('post.PartID','','strip_tags');
        $Article=D("Home/article_class");
        $Article->title=I('post.title','','strip_tags');
        $Article->sorting=I('post.sorting','','strip_tags');
        $request=$Article->where('id='.$id)->save();
        if ($request>0){
        $msg="<div class='Yoerror3'>操作成功！<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";
        echo json_encode(array("msg"=>$msg,"error"=>0,"url"=>$PartID));
        }else{
        $msg=$PartID."<div class='Yoerror1'>操作失败！产生错误的原因：可能是您没有输入信息<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";	
        echo json_encode(array("msg"=>$msg,"error"=>1,"url"=>$PartID));
        }
        }     

    public function index(){
       $this->display();
    }

    public function update(){
        //echo 'updatge';
        require APP_PATH.'Adminsys/Conf/system.php';
        $r_version = file_get_contents($sysconfig['updateurl']);

        $this->r_version = $r_version;
        $this->display();
    }

}