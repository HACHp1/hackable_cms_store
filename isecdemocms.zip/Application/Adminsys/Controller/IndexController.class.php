<?php

namespace Adminsys\Controller;
class IndexController extends AdminController {

    public function index(){
       //$this->checkadmin(array('2'));
       
       $this->display();
    }

    public function welcome(){
        //$this->checkadmin(array('2'));
        $this->display();
     }

    public function logout(){
    	session('uid',null);
    	$this->success('注销成功',U('Admin/Public/login'));
    }
}