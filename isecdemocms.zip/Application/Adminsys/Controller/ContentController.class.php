<?php

namespace Adminsys\Controller;
class ContentController extends AdminController {

    public function index(){
        //$this->checkadmin(array('2'));
        
        $this->display();
     }



    public function add(){
        //$this->checkadmin(array('2'));
        
        $this->display();
     }     

}