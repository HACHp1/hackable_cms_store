<?php
/** 
* 开放控制器
* @category Admin 
*/
namespace Adminsys\Controller;
use Think\Controller;
class PublicController extends Controller {
    public function login(){
        if(session('uid')) $this->redirect('/admin.php');
    	$this->display();
    }

    //登入检查
    public function login_post($username,$password){
        if($user = M('admin')->where("username='%s'",$username)->find()){//用户存在
            if($user['password'] == $password){//密码正确
                session('uid',$user['id']);
                $updateinfo = array(
                    'lastlogin'=>date('Y-m-d H:i:s',time()),
                    'lastip'  =>get_ip(),
                );
                M('admin')->where("username='%s'",$username)->save($updateinfo);
                $this->success('登入成功',U('Index/index'));
            }else{
                $this->error('用户名或密码错误');
            }
        }else{
            $this->error('用户名或密码错误');
        }

    }


    //验证码
    public function verify(){
    	$config =    array(
		    'fontSize'    =>    26,    // 验证码字体大小
		    'length'      =>    4,     // 验证码位数
		    'useNoise'    =>    ture, // 关闭验证码杂点
		);
		$Verify =     new \Think\Verify($config);
		$Verify->entry();
    }


    public function changePwd(){
        $oldpassword = I('oldpassword');
        $password = I('password');
        $repassword = I('repassword');
        if($repassword != $password){
            $this->error('密码不一致请检查');
            exit;
        }

        $user = M('users')->where("id=%d and pass='%s'",session('uid'),gethash($oldpassword))->find();
        if($user){
            if(M('users')->where('id=%d',session('uid'))->setField('pass',gethash($password))){
                
                $this->success('修改密码成功');
            }else{
                $this->error('修改失败');
            }
        }else{
            $this->error('密码不正确');
        }
    }



    public function findpwd(){
        $setup = I('get.setup');
        if(!$setup) $setup = 1;
        switch ($setup){
            case 1:
                $this->display();
                break;
            case 2:
                $username = I('username');
                $info = M('admin')->where("username='%s'",$username)->find();
                if($info){
                    $authcode = rand(4,4);
                    session('authcode',$authcode);
                    smssend($info['tel'],$authcode);
                    $this->display('findpwd2');
                }else{
                    $this->error('用户不存在');
                }
                break;
            case 3:
                $code = I('authcode');
                if(session('authcode')!==$code){
                    $this->error('验证码不正确');
                }else{
                    $this->display('findpwd3');
                }
                break;
            case 4:
                $username = I('username');
                $password = I('password');
                if(M('admin')->where("username='%s'",$username)->setField('password',$password)){
                    $this->success('重置密码成功');
                }
                break;
                
        }
    }



}