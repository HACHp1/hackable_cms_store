<?php

namespace Adminsys\Controller;
class DatabaseController extends AdminController {

    public function class_sorting(){
        cz_class_sorting("cz_article_class","0",$_GET['Point'],$_GET['id'],$_GET['sid'],$_GET['numberid'],$config);
        echo "<script>self.location=document.referrer;</script>";
        exit();	
    }

    public function backupdatabase($typs){
        if($type == 1){
            //本地处理
            $database = I('database');
            $database = $database ? $database : C('DB_NAME');
            $user = C('DB_USER');
            //$pass = C('DB_PWD');
            $pass = 'root';
            $system = "mysqldump -u$user -p$pass $database > ./upload/sql/$database";
            exec($system);
        }else{
            //远程处理
            $mysql_link=@mysql_connect($host,$uid,$dbps);
            mysql_select_db($db);
            $t1("SET NAMES gbk");
            $mysql="";
            $q1=mysql_query("show tables");
            while($t=mysql_fetch_array($q1)){
            $table=$t[0];
            $q2=mysql_query("show create table `$table`");
            $sql=mysql_fetch_array($q2);
            $mysql.=$sql['Create Table'].";\r\n\r\n";
            $q3=mysql_query("select * from `$table`");
            while($data=mysql_fetch_assoc($q3))
                {
                $keys=array_keys($data);
                $keys=array_map('addslashes',$keys);
                $keys=join('`,`',$keys);    
                $keys="`".$keys."`";
                $vals=array_values($data);
                $vals=array_map('addslashes',$vals);
                $vals=join("','",$vals);
                $vals="'".$vals."'";
                $mysql.="insert into `$table`($keys) values($vals);\r\n";
                }
            $mysql.="\r\n";
            }
            $filename=date("Y-m-d-GisA").".sql";
            $fp=fopen($filename,'w');
            fputs($fp,$mysql);
            fclose($fp);
        }  
    }



    public function index_class_add(){
        $Id=I('get.Id','','strip_tags');
        $Article=D("Home/article_class");
        #--------------------------------------------------------------------主目录添加
        if ($Id==''){
        $total  =$Article->count();
        #--------------------------------------------------------------------判断大目录是否有数据
        if ($total<>0){
        $list = $Article->field(array('NumberID'))->where("LagID=0")->order("NumberID desc,id desc")->limit(1)->select();
        $MJ=substr($list[0]['numberid'],1,20);
        $J=$MJ+1;
        }else{
        $J=0+1;
        }
        #--------------------------------------------------------------------判断大目录是否有数据 THE END
        $RootID=0;  
        $PartID=0;
        $LagID=0;
        $len=strlen($J);
        if ($len==1){
        $JJ="000$J";
        }elseif ($len==2){
        $JJ="00$J";
        }elseif ($len==3){
        $JJ="0$J";
        }elseif ($len==4){
        $JJ="$J";
        }
        #--------------------------------------------------------------------主目录添加
        }else{
        $len=strlen($Id);
        #--------------------------------------------------------------------二级目录添加
        if ($len==4){
        $total  =$Article->where("LagID=1 and PartID='$Id'")->count();
        if ($total!='0'){
        $list = $Article->field(array('NumberID'))->where("LagID=1 and PartID='$Id'")->order("NumberID desc,id desc")->limit(1)->select();
        $MJ=substr($list[0]['numberid'],4,20);
        $J=$MJ+1;
        }else{
        $J=0+1;
        } 
        $RootID="$Id";
        $PartID="$Id";
        $LagID=1;
        #--------------------------------------------------------------------三级目录添加
        }elseif ($len==8){
        $total  =$Article->where("LagID=2 and PartID='$Id'")->count();
        if ($total!='0'){
        $list = $Article->field(array('NumberID'))->where("LagID=2 and PartID='$Id'")->order("NumberID desc,id desc")->limit(1)->select();
        $MJ=substr($list[0]['numberid'],8,20);
        $J=$MJ+1;
        }else{
        $J=0+1;
        } 
        $RootID="$Id";
        $PartID="$Id";
        $LagID=2;
        }
        
        $lmyen=strlen($J);
        if ($lmyen==1){
        $JJ=$Id."000".$J;
        }elseif ($lmyen==2){
        $JJ=$Id."00".$J;
        }elseif ($lmyen==3){
        $JJ=$Id."0".$J;
        }elseif ($lmyen==4){
        $JJ=$Id.$J;
        }
        }
        $this->assign('RootID',$RootID);
        $this->assign('PartID',$PartID);
        $this->assign('LagID',$LagID);
        $this->assign('JJ',$JJ);
        $this->assign('J',$J);
        $this->display();
        }



}