<?php
/** 
* 后台基类控制器
* @category Admin 
*/
namespace Adminsys\Controller;
use Think\Controller;
class AdminController extends Controller {
    public $model = array();
    public $_G = array();
    public function __construct()
    {
    	parent::__construct();
        
    	//全局登入检测
    	if($uid = session('uid'))
    	{
    		$G['admin'] = M('admin')->where('id=%d',$uid)->find();
            $this->G = $G;
    	}
    	else
    	{
    		$this->error('请先登入后在完成操作',U('Public/login'));
        }
        

    }

    /** 
    * doPage 基类分页方法
    * @param object $model 模型实例
    * @param int $pagesize 分页大小
    * @return NULL
    */
    public function doPage(&$model,$pagesize = 20)
    {
        if(!$model) return;
        $_temp = clone $model;
        $count = $_temp->count();
        $currentPage = I('post.pageNum') ? I('post.pageNum') : 1;
        $startlimit = ($currentPage-1)*$pagesize;
        $this->param = array(
            'totalCount' => $count,//当前总共条数
            'currentPage' => $currentPage,//当前所在的页号
            'pagesize' => $pagesize,//每页显示条数
        );
        //设置limit
        $model->limit($startlimit,$pagesize);

    }





}