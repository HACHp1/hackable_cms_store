<?php $sysconfig=array (
  'updateurl' => 'http://localhost/README.md',
);