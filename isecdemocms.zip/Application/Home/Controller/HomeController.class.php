<?php
/** 
* 前台基类控制器
* @category Home 
* @date 2017-2-27
*/
namespace Home\Controller;
use Think\Controller;
class HomeController extends Controller {
    public $model = array();
    public function __construct()
    {
    	parent::__construct();


    }




}