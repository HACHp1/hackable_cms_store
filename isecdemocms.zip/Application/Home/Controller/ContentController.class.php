<?php
/** 
* 内容控制器
* @category Home 
*/
namespace Home\Controller;

use Think\Controller;

class ContentController extends HomeController
{

    public function _initialize()
	{
       //获取所有内容模型
       $this->model['type'] = M('type');
       $this->model['content'] = M('content');
	}



    public function class_sorting(){
        cz_class_sorting("cz_document","0",$_GET['Point'],$_GET['id'],$_GET['sid'],$_GET['numberid'],$config);
        echo "<script>self.location=document.referrer;</script>";
        exit();	
    }


    public function index_class_add(){
        $Id=I('get.Id','','strip_tags');
        $Article=D("Home/document");
        if ($Id==''){
            $total  =$Article->count();
            if ($total<>0){
                $list = $Article->field(array('NumberID'))->where("LagID=0")->order("NumberID desc,id desc")->limit(1)->select();
                $MJ=substr($list[0]['numberid'],1,20);
                $J=$MJ+1;
            }else{
                $J=0+1;
            }
            $RootID=0;  
            $PartID=0;
            $LagID=0;
            $len=strlen($J);
            if ($len==1){
                $JJ="000$J";
            }elseif ($len==2){
                $JJ="00$J";
            }elseif ($len==3){
                $JJ="0$J";
            }elseif ($len==4){
                $JJ="$J";
            }

        }else{
        $len=strlen($Id);

        if ($len==4){
            $total  =$Article->where("LagID=1 and PartID='$Id'")->count();
            if ($total!='0'){
                $list = $Article->field(array('NumberID'))->where("LagID=1 and PartID='$Id'")->order("NumberID desc,id desc")->limit(1)->select();
                $MJ=substr($list[0]['numberid'],4,20);
                $J=$MJ+1;
            }else{
                $J=0+1;
            } 
            $RootID="$Id";
            $PartID="$Id";
            $LagID=1;
        }elseif ($len==8){
            $total  =$Article->where("LagID=2 and PartID='$Id'")->count();
            if ($total!='0'){
                $list = $Article->field(array('NumberID'))->where("LagID=2 and PartID='$Id'")->order("NumberID desc,id desc")->limit(1)->select();
                $MJ=substr($list[0]['numberid'],8,20);
                $J=$MJ+1;
            }else{
                $J=0+1;
            } 
            $RootID="$Id";
            $PartID="$Id";
            $LagID=2;
        }

        $lmyen=strlen($J);
        if ($lmyen==1){
            $JJ=$Id."000".$J;
        }elseif ($lmyen==2){
            $JJ=$Id."00".$J;
        }elseif ($lmyen==3){
            $JJ=$Id."0".$J;
        }elseif ($lmyen==4){
            $JJ=$Id.$J;
        }
        }
        $this->assign('RootID',$RootID);
        $this->assign('PartID',$PartID);
        $this->assign('LagID',$LagID);
        $this->assign('JJ',$JJ);
        $this->assign('J',$J);
        $this->display();
    }


    public function index($id){
        if(!$id) return;
        //防注入处理
        $id = trim($id);
        $id = addslashes($id);
        $id = urldecode($id);
        //获取内容主栏目信息
        $ainfo = $this->model['content']->where("id='$id'")->find();
        if($ainfo){
            //获取栏目信息
            $tinfo = $this->model['type']->where("id='$ainfo[tid]'")->find();
            //获取栏目内容模板名
            $template = $tinfo['template_content_name'];
            $this->tinfo = $tinfo;
            
            $this->display($template);

        }else{
            $this->error('栏目不存在');
        }
        
    }




    public function index_ordera(){
        $Article=D("Home/document");
        $Action=I('get.Action','','strip_tags');
        $SId=I('get.SId','','strip_tags');
        if     ($Action=='close'){
            $Article->locks=1;
            $Article->where('id='.$SId)->save();
            echo "<script>self.location=document.referrer;</script>";exit();	
        }elseif($Action=='open'){
            $Article->locks=0;
            $Article->where('id='.$SId)->save();
            echo "<script>self.location=document.referrer;</script>";exit();	
        }elseif($Action==''){
            $NumberID=I('get.Id','','strip_tags');
            $len=strlen($NumberID);
            $search="1=1"; 
            if ($NumberID==''){
                $search=" LagID=0 ";
            }elseif($len==4 and $NumberID!=''){
                $search=" LagID=1 and Root1='$NumberID'";
            }elseif($len==8 and $NumberID!=''){
                $search=" LagID=2 and Root2='$NumberID'";
            }elseif($len==12 and $NumberID!=''){
                $search=" LagID=3 and Root3='$NumberID'";
            }
            if ($Id!='')$search.="  and title  like '%$keywords%' "; 
            $count  =$Article->count();
            $Page   = new  \Common\Page($count,30);
            $show   = $Page->paging();
            $list = $Article->field(array('id','title','NumberID','sorting','locks','id','lagid'))->where($search)->order("sorting asc")->limit($Page->limit)->select();
            $Start = $Article->field(array('sorting'))->where($search)->order("sorting asc,id desc")->limit(1)->select();
            $End   = $Article->field(array('sorting'))->where($search)->order("sorting desc,id desc")->limit(1)->select();
            $this->assign('Startid',$Start[0]['sorting']);
            $this->assign('Endid',$End[0]['sorting']);
            $this->assign('NumberID',$NumberID);
            $this->assign('list',$list);
            $this->assign('page',$show);
            $this->display();
        }
    }    


    
    //内容搜索控制器
    public function search(){
        $key = I('key');
        //缓存处理
        if($result = S($key)){
        $data = $result;
        }else{
            $db = M('content');
            $data = $db->where("title like '%%%s%%'",$key)->select();
            $data['key'] .= $key;
            S($key,$data);
        }
        $this->result = $data;
    }

}