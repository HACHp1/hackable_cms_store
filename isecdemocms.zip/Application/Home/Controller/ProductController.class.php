<?php
namespace Home\Controller;

use Think\Controller;

class ProductController extends HomeController
{


    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓执行数据的删除
    public function infodelete(){
        $id=$_POST['id'];
        $Article=D("Home/tms_ad");          ###实例化Data数据对象
        if ($_POST['Action']=='del'){
        $request=$Article->where('id='.$id)->delete();
        }else{
        $request=$Article->where(array('id'=>array('in',$id)))->delete();
        }
        if ($request>0){
        $msg="<div class='Yoerror3'>操作成功！<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";
        echo json_encode(array("msg"=>$msg,"error"=>0));
        }else{
        $msg="<div class='Yoerror1'>操作失败！产生错误的原因：可能该信息已经被删除<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";	
        echo json_encode(array("msg"=>$msg,"error"=>1));
        }

    }

    public function index($template = 'product')
    {
        $template = 'Content/'.$template;
        $this->display($template);
    }


    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓利用AR方法执行数据的修改
    public function info_edit(){
            if ($_POST['Action']==''){
            $id=I('get.Id',0,'intval');######安全模式过滤获取标签
            $Article=D("Home/tms_ad")->where("id=$id")->find();          ###实例化Data数据对象
            $this->assign('info',$Article);   ######赋值Id
            $this->display();	
            }elseif($_POST['Action']=='Edit'){
            $Id=I('post.Id',0,'intval');                ######安全模式过滤获取标签
            $title=I('post.title','','strip_tags');     ######安全模式过滤获取标题
            $picurl=I('post.qs','','strip_tags');     ######安全模式过滤获取标题
            // $ClassID=I('post.ClassID','','strip_tags'); ######安全模式过滤获取标题
            // $directory1=substr($ClassID,0,4);    ######文章一级栏目
            // $directory2=substr($ClassID,0,8);    ######文章二级栏目
            // $directory3=substr($ClassID,0,12);   ######文章三级栏目
            // $directory4=substr($ClassID,0,16);   ######文章四级栏目
            $content=I("post.content","",strip_tags);           ###内容
            $Article=D("Home/tms_ad");          ###实例化Data数据对象
            $Article->title=$title;
            $Article->id=$picurl;
            $Article->ad_1=$content;
            // $Article->directory1=$directory1;
            // $Article->directory2=$directory2;
            // $Article->directory3=$directory3;
            // $Article->directory4=$directory4;
            $begtime->begtime=time();
            $request=$Article->where('id='.$Id)->save();
            if ($request){
            $msg="<div class='Yoerror3'>操作成功！<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";
            echo json_encode(array("msg"=>$msg,"error"=>0));
            }else{
            $msg="<div class='Yoerror1'>操作失败！产生错误的原因：可能是您没有输入信息<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";	
            echo json_encode(array("msg"=>$msg,"error"=>1));
            }
            }
    }


    
}