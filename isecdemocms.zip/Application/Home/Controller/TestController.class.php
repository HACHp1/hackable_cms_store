<?php
namespace Home\Controller;

use Think\Controller;

class TestController extends HomeController
{

    public function _initialize()
	{
       $ip = $_SERVER['REMOTE_ADDR'];
       if($ip !== '127.0.0.1'){exit();}
       //从写数据库
       C('DB_TYPE','sqlite');
       C('DB_NAME','./test.php');
    }
    
    //自检md5
    public function test_indexa()
    {
        echo md5(file_get_contents(__FILE__));
    }

    //ip检测
    public function test_ip()
    {
        echo $_SERVER['SERVER_ADDR'];
    }

    //首页检测
    public function test_index()
    {
        A('Index')->index();
    }

    //内容页面功能检测
    public function test_content($id){
        A('Content')->index($id);
    }

    //搜索测试
    public function test_search(){
        A('Content')->search();
    }

    //登入测试
    public function test_login(){
        A('Adminsys/Public')->login_post('admin','admin');
    }

    public function test_login2(){
        A('Adminsys/Public')->login_post('admin','isec_test');
    }


    public function test_logout(){
        session('uid',null);
    }


}