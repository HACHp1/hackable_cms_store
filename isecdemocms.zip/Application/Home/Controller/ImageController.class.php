<?php
namespace Home\Controller;

use Think\Controller;

class ImageController extends HomeController
{
    public function display($src)
    {
        $width = I('width');
        $height = I('height'); 
        if(!$src) return;
        $src = strtolower($src);
        if((strpos($src,'://')!==false) || (strpos($src,'upload/')==false)){
            exit();
        }
        $src = str_replace('http','',$src);
        $image = file_get_contents($src);
        //处理图像的大小输出
        if($width && $height){
            $image = new \Think\Image();
            $image->open($src);
            $image->crop($width, $height);
        }else{
            echo $image;
        }
    }







}