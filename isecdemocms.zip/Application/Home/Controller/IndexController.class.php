<?php
namespace Home\Controller;

use Think\Controller;

class IndexController extends HomeController
{
    public function index()
    {
        $this->display('Index/index');
    }

}