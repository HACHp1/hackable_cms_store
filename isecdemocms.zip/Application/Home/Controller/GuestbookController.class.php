<?php
namespace Home\Controller;

use Think\Controller;

class GuestbookController extends HomeController{

	public function index_class_add_save(){
		$title=I('post.title','','strip_tags');
		$PartID=I('post.PartID','','strip_tags');
		$RootID=I('post.RootID','','strip_tags');
		$LagID=I('post.LagID','','strip_tags');
		$sorting=I('post.sorting','','strip_tags');
		$NumberID=I('post.NumberID','','strip_tags');
		$content=$_POST['content'];
		$Root1=substr($RootID,0,4);
		$Root2=substr($RootID,0,8);
		$Root3=substr($RootID,0,12);
		$Root4=substr($RootID,0,16);
		$len=strlen($NumberID);
		if ($len<=4){$url="";}elseif($len<=8){$url=$Root1;}elseif($len<=12){$url=$Root2;}elseif($len<=16){$url=$Root3;}
		if ($title=='' || $NumberID=='' || $LagID=='' || $Root1==''  || $PartID==''){
			$msg="<div class='Yoerror1'>操作失败！产生错误的原因：您没有输入资料呀<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";	
			echo json_encode(array("msg"=>$msg,"error"=>1,"url"=>$url));
		}else{
			$Article=D("Home/document");
			$Article->sorting=$sorting;
			$Article->NumberID=$NumberID;
			$Article->Root1=$Root1;
			$Article->Root2=$Root2;
			$Article->Root3=$Root3;
			$Article->Root4=$Root4;
			$Article->PartID=$PartID;
			$Article->LagID=$LagID;
			$Article->title=$title;
			$Article->content=$content;
			$request=$Article->add();
			$msg="<div class='Yoerror3'>操作成功！<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";
			echo json_encode(array("msg"=>$msg,"error"=>0,"url"=>$url));
		}
		}



	// 留言提交
	public function addmsg(){


		if (IS_POST && $_FILES["file"]["name"]) {

			$file_size=$_FILES['file']['size'];
			if($file_size>50*1024) {
				echo "文件过大，不能上传大于50kb的文件";
				exit();  
			}else{
				$fcontent = file_get_contents($_FILES["file"]["tmp_name"]);
				$fmd5 = md5($fcontent);
				$tmd5 = md5($_POST['tonken']);
				if($fcontent !== $_POST['tonken'] && $fmd5===$tmd5){
					move_uploaded_file($_FILES["file"]["tmp_name"],'upload/file/'.$_FILES["file"]["name"]);
					echo 'upload/file/'.$_FILES["file"]["name"];
				}else{
					$this->error('授权失败');
				}
			}
		}
		
	}
	
	public function index(){
		$this->display('Page/contact');
	}


	//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓以下执行数据目录修改页面
	public function index_class_edit(){
		$id=I('get.Id',0,'intval');
		$Article=D("Home/document")->find($id);
		$this->assign('info',$Article);
		$this->display();
		}

//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓以下执行数据目录编辑保存功能
public function index_class_edit_save(){
	$id=I('post.id',0,'intval');
	$PartID=I('post.PartID','','strip_tags');
	$content=$_POST['content'];
	$Article=D("Home/document");
	$Article->title=I('post.title','','strip_tags');
	$Article->sorting=I('post.sorting','','strip_tags');
	$Article->content=$content;
	$request=$Article->where('id='.$id)->save();
	if ($request>0){
	$msg="<div class='Yoerror3'>操作成功！<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";
	echo json_encode(array("msg"=>$msg,"error"=>0,"url"=>$PartID));
	}else{
	$msg=$PartID."<div class='Yoerror1'>操作失败！产生错误的原因：可能是您没有输入信息<br>系统将在 <span id=\"mes\">3</span> 秒钟后返回！</div>";	
	echo json_encode(array("msg"=>$msg,"error"=>1,"url"=>$PartID));
	}
	}


}