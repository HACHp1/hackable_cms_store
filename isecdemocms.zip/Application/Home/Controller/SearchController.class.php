<?php
namespace Home\Controller;

use Think\Controller;

class SearchController extends HomeController
{
    public function index($key)
    {
        
    }
    
}