<?php
$file_name=array("aaaaa & cat flag.rar");

if(preg_match("/flag/",$file_name)){
    die("请不要输入奇奇怪怪的字符！");
}
if(is_array($file_name)){
    $file_name=implode($file_name);
}
echo $file_name."\n";
echo trim($file_name)."\n";
if(!preg_match("/^[a-zA-Z0-9-s_]+.rar$/m", trim($file_name))) {
    echo "请输入正确的文件名";
}else{
    echo "/usr/bin/md5sum " . $file_name;
}