<?php
include "waf.php";
isset($_SESSION) OR session_start();

if (!$_SESSION["login"] === true) {
    header("Location:login.php");
    exit();
}
?>
<html>
<head>
    <title>Homepage</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <script src="js/jquery-3.4.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            var pbar = $("#pbar");
            pbar.width("50%");

            function success(object, Sat) {
                console.log(Sat);
                if (Sat === "success") {
                    $("#rettext")[0].innerText = "lock created at " + object;
                    pbar.width("100%");
                }
                $("#rettext").fadeTo(100,0);

            }

            var ts = Date.parse(new Date());
            $.ajax({
                type: 'POST',
                url: "login-lock.php",
                data: {"time": ts},
                success: success
            });
        });

    </script>
</head>
<main role="main">
    <div class="container">
        <div class="progress align-content-center" style="margin-top: 4em">
            <div id="pbar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
                 aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0"></div>
        </div>
        <div>
            <p style="text-align: center" id="rettext">session check ok, login lock creating...</p>
        </div>
    </div>
    <div class="container">
        <?php
        $file1 = $_SESSION["name"].".jpg";
        $file2 = $_SESSION["name"].".jpeg";
        $file3 = $_SESSION["name"].".png";
        if(file_exists("files/".$file1))
        {
            echo "<img src='files/".$file1."'"."height=\"200\" width=\"200\">";
        }
        else if(file_exists("files/".$file2))
        {
            echo "<img src='files/".$file2."'"."height=\"200\" width=\"200\">";
        }
        else if(file_exists("files/".$file3))
        {
            echo "<img src='files/".$file3."'"."height=\"200\" width=\"200\">";
        }
        else
        {
            echo "<img src='default.jpg'>";
        }
        ?>
        <div>
        <form action="file_upload.php" method="post" enctype="multipart/form-data">
            设置头像
            <div>
            <input type="file" name="file"/></div>
        </div>
        <div class="form-group"><input class="btn btn-primary" type="submit" value="上传"/></div>
        </form>
    </div>
</main>
</html>
