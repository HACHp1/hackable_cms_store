<?php
$db_name = "ctf";
$db_user = "root";
$db_pass = "";
$blacklist = array(".jsp", ".jspa", ".jspx", ".jsw", ".jsv", ".jspf", ".jtml", ".jSp", ".jSpx", ".jSpa", ".jSw", ".jSv", ".jSpf", ".jHtml", ".asp", ".aspx", ".asa", ".asax", ".ascx", ".ashx", ".asmx", ".cer", ".aSp", ".aSpx", ".aSa", ".aSax", ".aScx", ".aShx", ".aSmx", ".cEr", ".sWf", ".swf", ".ini", ".iis", "asp", "asa", "cer", "cdx", "aspx", "ashx", "ascx", "asax", "php", "php2", "php3", "php4", "php5", "asis", "htm", "html", "shtml", "pwml", "phtml", "phtm", "js", "jsp", "vbs", "asis", "sh", "reg", "cgi", "exe", "dll", "com", "bat", "pl", "cfc", "cfm", "ini");
function usernamecheck1($str)
{
    preg_match('/(\/)|(\*)|(~)|(-)/', $str, $matches);
    if(sizeof($matches)==0){
        return 0;
    }
    else{
        return 1;
    }
}

function usernamecheck2($str)
{
//TODO 过滤不可见字符
}
