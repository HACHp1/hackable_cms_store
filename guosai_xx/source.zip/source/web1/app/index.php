<?php
include "waf.php";
//echo "1";
?>
<html>
<head>
    <title>Homepage</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-3.4.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand col-2">Welcome</a>
        <div class="collapse navbar-collapse col-4">
            <ul class=" navbar-nav">
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="signup.php">Sign up</a></li>
            </ul>
        </div>
    </div>
</nav>
<main role="main" class="container">
    <div style="text-align: center;padding: 3em 1.5em">
        <h1>真的不是sql注入</h1>
    </div>

</main>
</body>
</html>
