<?php
include "config.php";
include "waf.php";

$db = mysqli_init();
if (!$db) {
    die('init error!');
}
if (!$db->real_connect('localhost', $db_user, $db_pass, $db_name)) {
    die('connect error!');
}


if (isset($_GET["username"]) && isset($_GET["password"])) {
    $name = $_GET["username"];
    $password = $_GET["password"];
    $password = strval(md5($password));


    preg_match('/(.+)(?=\.)/', $name, $matches); //只要发现.前面有东西就干死
    if (!sizeof($matches) == 0 OR usernamecheck1($name)) {
        echo "<script>alert('seems you want to write some bad file? BIG BROTHER IS WATCHING YOU')</script>";
        ++$_SESSION["hacker"];
        die();
    }


    if ($stmt = $db->prepare("SELECT username FROM users WHERE username=?")) {
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $stmt->bind_result($id);
        $stmt->fetch();
        $stmt->close();
        if (!is_null($id)) {
            echo '<script>alert("用户名已被注册!")</script>';
        } else {
            if ($stmt = $db->prepare("INSERT INTO users VALUES (?, ?)")) {
                $stmt->bind_param('ss', $name, $password);
                $ok = $stmt->execute();
                $stmt->close();
                if ($ok) {
                    echo '<script>alert("注册成功!")</script>';
                } else {
                    echo '<script>alert("出错了QAQ")</script>';
                }
            } else {
                echo '<script>alert("出错了QAQ")</script>';
            }
        }
    } else {
        echo '<script>alert("出错了QAQ")</script>';
    }
}
?>
<html>
<head>
    <meta charset="utf-8">
</head>
</html>
<html>
<head>
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand col-2">Sign Up</a>
        <div class="collapse navbar-collapse col-4">
            <ul class=" navbar-nav">
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="signup.php">Sign up</a></li>
            </ul>
        </div>
    </div>
</nav>
<h1 style="text-align: center;margin-top: 2em;">注册</h1>
<main role="main" class="container">
    <form action="signup.php" method="get" style="text-align: center;">
        昵称:<input class="form-group" type="text" name="username" style="margin:30px 8px 0px 8px"><br>
        密码:<input class="form-group" type="password" name="password" style="margin:8px"><br>
        <input class="btn btn-primary" type="submit" value="注册"><br><br>
    </form>
</main>
</body>
</html>
