<?php
include "waf.php";
isset($_SESSION) OR session_start();

if (!$_SESSION["login"] === true) {
    header("Location:login.php");
    exit();
}

//取文件信息
$arr = $_FILES["file"];
$name = iconv("UTF-8", "GB2312", $arr["name"]);
//var_dump($arr);
//加限制条件
//1.文件类型
//2.文件大小
//3.保存的文件名不重复
function getCharpos2($str, $char)
{
    $len = strlen($str);
    $j = 0;
    $arr_ = array();
    $count = substr_count($str, $char);
    // echo $count;
    $avai = 1;
    //基本判断（后缀名）
    $uploaded_ext = substr($str, strrpos($str, '.') + 1);
    if ((strtolower($uploaded_ext) == "jpg" || strtolower($uploaded_ext) == "jpeg" || strtolower($uploaded_ext) == "png")) {
        //所有带.的
        for ($i = 0; $i < $count; $i++) {
            $j = strpos($str, $char, $j);
            if (!((strtolower($str[$j + 1]) == 'p' && strtolower($str[$j + 2]) == 'n' && strtolower($str[$j + 3]) == 'g') 
                || 
                (strtolower($str[$j + 1]) == 'j' && strtolower($str[$j + 2]) == 'p' && strtolower($str[$j + 3]) == 'g') 
                || 
                (strtolower($str[$j + 1]) == 'j' && strtolower($str[$j + 2]) == 'p' && strtolower($str[$j + 3]) == 'e' && strtolower($str[$j + 4]) == 'g')))
            {
                $avai = 0;
            }
            $j = $j + 1;
        }
    } 
    else {
        $avai = 0;
    }
    return $avai;
}

//print_r(getCharpos2($arr["name"],'.'));
if (($arr["type"] == "image/jpeg" || $arr["type"] == "image/png") && $arr["size"] < 10241000 && getCharpos2($name, '.') == 1) {
//临时文件的路径
    $arr["tmp_name"];
//上传的文件存放的位置
//避免文件重复: 
//1.加时间戳.time()加用户名.$uid或者加.date('YmdHis')
//2.类似网盘，使用文件夹来防止重复
    $filename = "./files/" . date('YmdHis') . $arr["name"];
//保存之前判断该文件是否存在
//  if(file_exists($filename))
//  {
//    echo "该文件已存在";
//  }
//  else
//  {
    //中文名的文件出现问题，所以需要转换编码格式
    //$filename = iconv("UTF-8","GB2312",$filename);
    //移动临时文件到上传的文件存放的位置（核心代码）
    //括号里：1.临时文件的路径, 2.存放的路径
    $file_name = $_SESSION["name"].'.'.strtolower(substr($name, strrpos($name, '.') + 1));
    move_uploaded_file($arr["tmp_name"], "./files/".$file_name);
    echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    echo "Type: " . $_FILES["file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
    //echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
    echo "Stored in: " . "./files/" . $file_name;

//  }
} else {
    echo "Invalid file type or file size";
}
?>