<?php
error_reporting(0);
header("content-type:text/html;charset=utf-8");
session_start();
$ua = $_SERVER['HTTP_USER_AGENT'];
if (!isset($_SESSION["hacker"])) {
    $_SESSION["hacker"] = 0;
}
if ($_SESSION["hacker"] == 4) {
    header("Location:hacker.html");
    die();
}
if (preg_match("/Windows/", $ua)) {
    echo "windows不好玩 换一个操作系统吧";
    die();
} else {
    if (!preg_match("/touhou/", $ua)) {
        if (preg_match("/Chrome/", $ua)) {
            echo "请不要使用Chrome";
            die();
        } elseif (preg_match("/Firefox/", $ua)) {
            echo "请不要使用Firefox";
            die();
        } elseif (preg_match("/Trident/", $ua)) {
            echo "IE还是别用了";
            die();
        } elseif (preg_match("/360/", $ua)) {
            echo "请不要使用360";
            die();
        } elseif (preg_match("/Safari/", $ua)) {
            echo "请不要使用safari";
            die();
        } elseif (preg_match("/python/", $ua)) {
            echo "请使用浏览器";
            die();
        } else {
            echo $ua;
            echo "是什么奇怪的浏览器 我觉得用东方浏览器比较合适(touhou)";
            die();
        }
    }
}