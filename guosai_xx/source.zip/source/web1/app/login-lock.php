<?php
include "waf.php";
isset($_SESSION) OR session_start();

if (!$_SESSION["login"] === true) {
    header("Location:login.php");
    exit();
}
if (isset($_POST["time"])) {
    $time = $_POST["time"];
    $lock = fopen("files/" . $_SESSION["name"], "w");
    fwrite($lock, $time);
    fclose($lock);
    sleep(2);//假装处理要消耗不少时间 让动画好看一点
    echo "files/" . $_SESSION["name"];
}