<?php
error_reporting(0);
include "config.php";
include "waf.php";
//3个参数 没有action就什么都不做
//echo md5($_POST["action"]);
isset($_SESSION) OR session_start();
if ($_POST["action"] === "login") {
    if ($_POST["username"] === "") {
        echo "<script>alert('请输入用户名')</script>";
    } else {
        if ($_POST["password"] === "") {
            echo "<script>alert('请输入密码')</script>";
        } else {
            $user = $_POST["username"];
            $pass = $_POST["password"];

            $query = new mysqli("localhost", $db_user, $db_pass, $db_name);
            if (mysqli_connect_errno()) {
                printf("Connect failed: %s\n", mysqli_connect_error());
                exit();
            }
            $stmt = $query->prepare('SELECT * FROM users WHERE username = ?');
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $stmt->bind_result($username, $password);
            $stmt->fetch();

            if (md5($pass) == $password) {

                if (file_exists("files/" . $user)) { //判断登陆过没有
                    if ($_SESSION["login"] === true) {
                        echo "<script>alert('You have already logged in. 用户登录信息会在5分钟内清除');window.location.href='admin-index.php';</script>";
                        exit();

                    } else {
                        echo "<script>alert('Somebody else has logged in. 用户登录信息会在5分钟内清除');window.location.href='index.php';</script>";
                        exit();
                    }
                }

                echo "ojbk";
                $_SESSION["login"] = true;
                $_SESSION["name"] = $username;
                header("Location:admin-index.php");
                exit();

            } else {
                ++$_SESSION["hacker"];
                echo "<script>alert('出现了一些偏差')</script>";

            }
            //var_dump($password);
            //参考https://www.php.net/manual/zh/mysqli.prepare.php
        }
    }
} ?>
<html>
<head>
    <title>Homepage</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <script src="js/jquery-3.4.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<main role="main">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand col-2">Welcome</a>
            <div class="collapse navbar-collapse col-4">
                <ul class=" navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="signup.php">Sign up</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <h1 style="text-align: center;margin-top: 2em;">这里没有注入点</h1>
    <div class="container" style="text-align: center"
    ">
    <div style="text-align: center;  margin-top: 1em" class="col-4 offset-4">
        <form style="" method="post">
            <div class="form-group">
                <label for="loginusername">Username</label>
                <input id="loginusername" class="form-control" name="username" type="username">
            </div>
            <div class="form-group">
                <label for="loginpassword">Password</label>
                <input id="loginpassword" class="form-control" name="password" type="password">
            </div>
            <div class="form-group">
                <input class="form-control" name="action" value="login" hidden>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    </div>
</main>
</html>
